Hola!!
Actualmente funciona, pero me falta aún el tema de crear los archivos
pero ya son las 3:51am y tengo que salir a las 5 para llegar a la escuela.

Hasta aqui es donde llegué del codigo hasta ahora, creo que aprendí pero ya algo tarde

Pero nada mal para alguien que no entendía ni como crear una clase, no?
